static void record_batch(int boxes)
{
    unsigned i = 0;
    while (i < 6) {
        shipped_units += boxes;
        ++i;
    }
}
