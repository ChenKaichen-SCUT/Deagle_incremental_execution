static void record_batch(int boxes)
{
    shipped_units += boxes * 2;
    shipped_units += boxes * 2;
}
