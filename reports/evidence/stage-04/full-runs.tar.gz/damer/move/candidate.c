int a,b,c;
int main(){
b=2;
a=1;
c=3;
return 0;
}
