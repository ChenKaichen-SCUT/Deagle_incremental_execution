int a,b,c;
int main(){
a=1;
a=4;
b=2;
c=3;
return 0;
}
