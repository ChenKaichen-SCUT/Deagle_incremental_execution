int a,b,c;
int main(){
a=1;
c=3;
return 0;
}
