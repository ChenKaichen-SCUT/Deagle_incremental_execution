from pathlib import Path
import gzip, hashlib, json, shutil, sys, tarfile
d=Path(sys.argv[1]); ev=d/'final-evidence'; scratch=Path(sys.argv[2]); extra=Path(sys.argv[3])
def save(p,obj): p.write_text(json.dumps(obj,indent=2)+'\n')
def zi(src,dest):
    with src.open('rb') as f, gzip.GzipFile(str(dest),'wb',mtime=0) as o:shutil.copyfileobj(f,o)
two=ev/'d2-regression'; two.mkdir()
shutil.copyfile(d/'final-d2-regression/summary.json',two/'summary.json')
for a in ('final-d2-regression.log','final-d2-build.log'):zi(d/a,two/(a+'.gz'))
with tarfile.open(two/'cases.tar.gz','w:gz') as out:out.add(d/'final-d2-regression',arcname='fixtures')
dom=ev/'expanded-domain';dom.mkdir()
for a in ('supports.json','summary.json'):shutil.copyfile(extra/'evidence'/a,dom/a)
shutil.copyfile(extra/'run.py',dom/'run.py')
for a in ('guard-review.json','guard-review.py'):shutil.copyfile(extra/a,dom/a)
with tarfile.open(dom/'raw.tar.gz','w:gz') as out:out.add(extra/'evidence',arcname='evidence')
joint=ev/'public-joint';joint.mkdir()
shutil.copyfile(d/'final-public-joint/joint-invalidate.cc',joint/'joint-invalidate.cc')
shutil.copyfile(d/'final-public-joint/summary.json',joint/'summary.json')
replay={}
for c in ('fib_updates_8','circular-buffer','airline_reservations_6'):
    dst=joint/c;dst.mkdir()
    ob=d/'final-public-joint'/c
    for f in ('public-births.tsv','retained-ids.tsv','times.tsv'):zi(ob/f,dst/(f+'.gz'))
    shutil.copyfile(ob/'receipt.json',dst/'receipt.json')
    x=(d/'archived-replay'/(c+'.log')).read_text().splitlines()
    assert x[-1].endswith(' verified')
    replay[c]=dict(exact_archive_replay=x[-1], scopes=['improved','frozen'], regenerated='metrics, learned, used, survivors, mixed witness when present')
save(ev/'replay.json',replay)
shutil.copyfile(d/'final-trace-review.json',ev/'trace-comparison.json')
for f in ('describe_results.py','finalize_evidence.py','supplement.py','pre-fix.py'):zi(scratch/f,ev/'toolchain'/(f+'.gz'))
