"""Preserve the prior full cohort and verify whether its proof payloads match the final run."""
from pathlib import Path
import gzip,hashlib,json,shutil,sys,tempfile
d=Path(sys.argv[1]);ev=d/'final-evidence';prior=d.parent/'final-evidence';sc=Path(sys.argv[2])
sys.path.insert(0,str(d/'final/dependency-reuse/scripts'))
from recheck_d2 import restore
from run_stock import save
def get(p):return json.loads(p.read_text())
def copy(s,t):t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(s,t)
p=ev/'pre-fix';p.mkdir()
for f in ('plan.json','summary.json','mapping/plan.json','mapping/summary.json','mapping/native-cost.json','toolchain/build.json','public-joint/summary.json'):
    copy(prior/f,p/f)
for f in ('case.cc','observations.txt','proof.bin.gz','sha256.txt','source-commit.txt'):
    copy(sc/'rmw-before'/f,p/'rmw'/f)
raw={}
for c in get(ev/'summary.json'):
    root=prior/'pairs'/c
    new=get(ev/'pairs'/c/'runs.json')
    old=get(root/'runs.json')
    copy(root/'runs.json',p/'pairs'/c/'runs.json')
    current={r['logical_sha256']:r['compressed_payload'] for r in new if 'compressed_payload' in r}
    raw[c]=[]
    for r in old:
        process=r['mode']+'-'+str(r['repeat'])
        for f in ('trace.json','run.json','result.json','stdout.gz','stderr.gz'):
            copy(root/process/f,p/'pairs'/c/process/f)
        if 'compressed_payload' not in r:continue
        k=r['logical_sha256']; row={'mode':r['mode'],'repeat':r['repeat'],'sha256':r['raw_sha256'],'identical_logical_payload':k in current}
        if k in current:
            repro=dict(r,compressed_payload=current[k])
            with tempfile.TemporaryDirectory() as wd:restore(ev,c,repro,Path(wd)/'proof.bin')
            row['final_payload']=current[k]
        else:
            s=root/r['compressed_payload'];t=p/'pairs'/c/r['compressed_payload']
            if not t.exists():copy(s,t)
            with tempfile.TemporaryDirectory() as wd:restore(p,c,r,Path(wd)/'proof.bin')
            row['separate_payload']=r['compressed_payload']
        raw[c].append(row)
    assert all(r['improved_hashes']==next(z for z in new if z['mode']==r['mode'] and z['repeat']==r['repeat'])['improved_hashes'] for r in old if 'improved_hashes' in r)
save(p/'archive-comparison.json',raw)
