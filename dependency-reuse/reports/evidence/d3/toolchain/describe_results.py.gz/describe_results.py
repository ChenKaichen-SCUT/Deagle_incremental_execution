"""Derive disjoint retirement counts and the exact P0 declaration kinds in each retired mixed proof."""
import collections
import json
import mmap
import struct
import sys
from array import array
from pathlib import Path
d=Path(sys.argv[1])
ev=d/'final-evidence'
kinds=('Config','PO','APO','RFBinding','GuardBinding','EventSchema','SameAddress','BlockCertificate')
def save(p,obj):p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
for pair in sorted((ev/'pairs').iterdir()):
    c=pair.name
    src=d/'final-runs'/c/'mixed-1/proof.bin'
    dest=d/'final-checks'/c
    cat=[list(map(int,l.split())) for l in (dest/'mixed-1/improved/learned.tsv').read_text().splitlines()]
    with src.open('rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
        sections=[]; pos=12
        for width in (16,4,8,16,12,8,12,4,4,4,4,4,20,1):
            n=struct.unpack_from('<I',data,pos)[0];sections.append((pos+4,n));pos+=4+n*width
        ns,n=sections[0];zs,ne=sections[2];ts,nt=sections[12]
        nodes=memoryview(data)[ns:ns+16*n].cast('I');edges=memoryview(data)[zs:zs+8*ne].cast('I')
        masks=array('H',[0])*n
        decl={tuple(map(int,t[1:5])):t[5] for t in (line.split() for line in (dest/'improved/declarations.txt').open()) if t[0]=='D'}
        for j in range(nt):
            id_,op,a,b,cc=struct.unpack_from('<IIiii',data,ts+20*j)
            if nodes[4*id_+2]==12:
                status=decl[(op,a,b,cc)]
                if status!='M':masks[id_]=1<<(op+(8 if status=='U' else 0))
        beg=0
        for i in range(n):
            end=nodes[4*i+1]
            if end!=beg:
                value=masks[i]
                for j in range(2*beg,2*end,2):value|=masks[edges[j]]
                masks[i]=value
            beg=end
        del edges,nodes
    groups=collections.defaultdict(collections.Counter);by_decl=collections.Counter();all_counts=collections.Counter()
    for row in cat:
        i,_,flags,_,cause,resident,unit,survives,translated,*_=row
        typ='opaque_theory' if flags&1 else 'missing' if flags&4 else 'query_scoped' if flags&2 else 'permanent_mixed' if row[-1] else 'permanent_theory_only' if flags&8 else 'permanent_boolean'
        all_counts[typ]+=1
        if typ not in ('permanent_mixed','permanent_theory_only','permanent_boolean'):continue
        b=bool(cause&7);t=bool(cause&768)
        assert bool(masks[i])==t and bool(survives)==(not b and not t)
        reason=('B+T' if b and t else 'B' if b else 'T' if t else 'survives')
        groups[typ][reason]+=1
        if typ=='permanent_mixed':
            for bit in range(16):
                if masks[i]&(1<<bit):by_decl[kinds[bit%8]+('_unknown' if bit>=8 else '_changed')]+=1
    witness=dest/'mixed-1/improved/mixed-witness.tsv'
    sample={}
    if witness.is_file():
        rows=witness.read_text().splitlines()
        if rows:
            root=int(rows[0].split()[1])
            parsed={}
            for line in rows[1:]:
                s=line.split();i,k,fl=map(int,s[1:4]);j=s.index('P');t=s.index('T') if 'T' in s else len(s)
                ps=[(int(e.split('/')[0]),int(e.split('/')[1])) for e in s[j+1:t]]
                parsed[i]=dict(kind=k,flags=fl,lits=list(map(int,s[5:j])),parents=ps,op=s[t+1:s.index('C')] if t<len(s) else None)
            if root in parsed:
                data=parsed[root]
                counts=collections.Counter(x['kind'] for x in parsed.values())
                lemmas=[(i,v) for i,v in parsed.items() if v['kind']==14]
                sample=dict(root=root,root_record=data,ancestry_by_kind=counts,first_boolean=next(((i,v) for i,v in parsed.items() if v['kind']==1),None),
                    first_lemma=lemmas[0] if lemmas else None,first_lemma_rule=parsed[lemmas[0][1]['parents'][0][0]] if lemmas else None)
    save(pair/'retirement.json',dict(disjoint_learning_classes=all_counts,disjoint_complete_outcomes=groups,
        failed_declarations_among_complete_mixed_overlapping=by_decl,mixed_witness=sample))
