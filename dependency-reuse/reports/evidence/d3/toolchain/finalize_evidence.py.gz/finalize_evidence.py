"""Capture reproducibility receipts and audit the published D3 files."""
from pathlib import Path
import collections,gzip,hashlib,json,platform,shutil,subprocess,sys,tarfile,tempfile
d=Path(sys.argv[1]);source=d/'final';ev=d/'final-evidence';tools=d/'final-tools'
sys.path.insert(0,str(source/'dependency-reuse/scripts'))
from diff_d1 import digest
from package_d1 import packed
from run_stock import BASE,save
from run_d1 import CASES
from recheck_d2 import restore
def git(*args):return subprocess.check_output(['git','-C',source,*args],text=True).strip()
def read(p):return json.loads(p.read_text())
tool=ev/'toolchain';tool.mkdir()
for name in ('final-build.log','final-test-build.log','final-mapping.log','final-runs.log','final-checks.log','final-micro.log','final-mapping-tests.log'):
    packed(d/name,tool/(name+'.gz'))
shutil.copyfile(d/'final-build.time',tool/'clean-build-time.txt')
for f in ('recipes.json','ClosureSolver.cc'):
    packed(d/'observer'/f,tool/(f+'.gz'))
with tarfile.open(ev/'micro-raw.tar.gz','w:gz') as t:t.add(d/'final-micro',arcname='micro')
shutil.copyfile(d/'final-micro/results.json',ev/'micro-results.json')
shutil.copyfile(d/'final-micro/corruption-results.json',ev/'corruption-results.json')
scope=ev/'native-scope';scope.mkdir()
for f in ('observations.txt','sha256.txt'):shutil.copyfile(d/'final-scope'/f,scope/f)
for f in ('scope.bin','dynamic.bin','aliased.bin'):packed(d/'final-scope'/f,scope/(f+'.gz'))
archive_receipts={}
for case in CASES:
    pair=ev/'pairs'/case
    known={digest(d/'final-runs'/case/'joint-1/native.tsv'):pair/'P0-native.tsv.gz',digest(d/'final-mapping/manifests'/case/'P1/after/native.tsv'):pair/'P1-native.tsv.gz'}
    p0=d/'final-mapping/manifests'/case
    for side in ('P0','P1'):
        for mode in ('before','after'):
            dat=p0/side/mode;out=ev/'mapping'/case/side/mode;out.mkdir(parents=True)
            for f in ('run.json','result.json'):shutil.copyfile(dat/f,out/f)
            for f in ('stdout','stderr'):packed(dat/f,out/(f+'.gz'))
            h=digest(dat/'native.tsv')
            if h not in known:
                known[h]=out/'native.tsv.gz'
                packed(dat/'native.tsv',known[h])
            save(out/'identity.json',dict(raw_sha256=h,archived=str(known[h].relative_to(ev))))
    for old in ('pairs','self','baseline'):
        z=d/'final-mapping'/old/case
        dst=ev/'mapping'/case/old
        dst.mkdir()
        for file in ('summary.json','variables.tsv.gz','clause-counts.tsv.gz','occurrences.tsv.gz'):
            shutil.copyfile(z/file,dst/file)
    obs=d/'observer-runs'/case
    for f in ('stdout','stderr'):packed(obs/f,pair/('observer-'+f+'.gz'))
    shutil.copyfile(obs/'run.json',pair/'observer-run.json')
    replays=[]
    for r in read(pair/'runs.json'):
        if 'raw_sha256' not in r:continue
        with tempfile.TemporaryDirectory() as t:restore(ev,case,r,Path(t)/'proof')
        replays.append(dict(mode=r['mode'],repeat=r['repeat'],restored_sha256=r['raw_sha256']))
    archive_receipts[case]=replays
binaries={'native':source/'src/cbmc/deagle_exe','checker':tools/'check','diff':tools/'diff','D2_checker':tools/'d2-check',
 'D1_boundary_observer':d/'observer/deagle_exe','fixture':tools/'native','fixture_oracle':tools/'oracle','scope_fixture':d/'final-scope/native-scope'}
receipt=dict(upstream='d8c79eaba5df03b1a013dc6ffbb3a1e249485c1e',reviewed_D2='8f7668a4113a67275d3bc1af45e663729c5cf35e',
 initial_d3_implementation=git('rev-parse','HEAD^^'),test_delimiter_fix=git('rev-parse','HEAD^'),
 final_tree_commit=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),
 compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],kernel=platform.release(),wsl='Deagle-Jammy',
 frozen_lock_sha256=digest(BASE/'bench/manifest.json'),clean_build='LC_ALL=C PATH=/usr/bin:/bin make -C src -j12 cbmc.dir',
 binaries_sha256={k:digest(v) for k,v in binaries.items()},d2_regression='d2-regression/summary.json')
save(tool/'build.json',receipt)
save(ev/'restored-archives.json',archive_receipts)
for p in ('pilot01','pilot02','pilot03'):
    directory=d/p
    rows=[]
    for case in CASES:
        dest=directory/case/'joint-1'
        z=read(dest/'run.json');result=read(dest/'result.json')
        rows.append(dict(case=case,exit_code=z['exit_code'],rss_kib=z['peak_rss_kib'],wall_ns=z['wall_ns'],
                         solver_s=result['queries'][0]['property_decider_solve_s'],proof_bytes=(dest/'proof.bin').stat().st_size))
    save(tool/(p+'.json'),dict(plan=read(directory/'plan.json'),samples=rows))
