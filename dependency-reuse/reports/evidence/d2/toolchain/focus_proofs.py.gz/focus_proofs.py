from pathlib import Path
import json, struct,sys
from collections import Counter
base=Path.home()/'dependency-reuse'
d=base/'runs/d2';ev=d/'release-evidence'
sys.path.insert(0,str(base/'native/dependency-reuse/scripts'))
from inspect_d2_used import Archive,Sites
from run_stock import BASE,save
from prepare_d2 import metadata
def few(s):return sorted(s)[:4]
out={}
for case in ('circular-buffer','airline_reservations_6'):
    x=Archive(d/'release-runs'/case/'on-1/knowledge.bin')
    n,ls,ed=x.sections[:3]
    cat={r[0]:r for r in (list(map(int,row.split())) for row in (d/'release-checks'/case/'learned.tsv').open())}
    examples=json.loads((ev/'pairs'/case/'used-input-analysis.json').read_text())['examples']
    ids=[i for i,r in cat.items() if r[2]==0 and r[4] in (2,66,130)]
    ids.extend(examples[key]['first_learned_descendant'] for key in (
        ('unchanged_frozen_line_gate','fully_mapped_absent') if case=='circular-buffer' else ('self_also_aux_and_other','self_also_aux_only')))
    used={r[1]:(r[0],r[3]) for r in (list(map(int,row.split())) for row in (d/'release-checks'/case/'used.tsv').open())}
    vd,_=metadata(BASE/'reports/evidence/d1/pairs'/case)
    sites=Sites(BASE/'reports/evidence/d1/runs/record'/case/'P0/native.tsv.gz')
    def parents(i):
        start=struct.unpack_from('<I',x.data,n+16*(i-1)+4)[0];end=struct.unpack_from('<I',x.data,n+16*i+4)[0]
        return [struct.unpack_from('<I',x.data,ed+8*j)[0] for j in range(start,end)]
    def lits(i):
        first=struct.unpack_from('<I',x.data,n+16*(i-1))[0];last=struct.unpack_from('<I',x.data,n+i*16)[0]
        return struct.unpack_from('<'+'i'*(last-first),x.data,ls+4*first)
    rows=out[case]=[]
    for i in sorted(set(ids)):
        seen={i};work=[i];previous={}
        while work:
            child=work.pop()
            for p in parents(child):
                if p not in seen:seen.add(p);work.append(p);previous[p]=child
        pp={leaf:used[leaf] for leaf in seen & used.keys()}
        causes=Counter(cause for _,cause in pp.values())
        mask=0
        for cause in causes:mask|=cause
        assert cat[i][2]==0 and mask==cat[i][4]
        samples=[]
        for cause in sorted(causes):
            available=[leaf for leaf,(_,cs) in pp.items() if cs==cause]
            for leaf in few(available)[:1]:
                path=[leaf]
                while path[-1]!=i:path.append(previous[path[-1]])
                variables=[]
                for l in lits(leaf):
                    peer,role,why=vd[l//2]
                    if peer>=0:continue
                    j=l//2;trail=[]
                    while vd[j][2].startswith('unmapped_gate_input:'):
                        op,ins=sites.gates[j];raw=int(vd[j][2].partition(':')[2]);assert raw in ins
                        trail.append([j,op,raw]);j=raw//2
                    variables.append(dict(raw_literal=l,role=role,first_reason=why,gate_path=trail,terminal_variable=j,
                        terminal_reason=vd[j][2],terminal_bits=sites.bits.get(j,[])[:2]))
                samples.append(dict(source_occurrence=pp[leaf][0],proof_id=leaf,cause=cause,raw_literals=lits(leaf),
                    path=path,unmapped_literals=variables))
        rows.append(dict(learned_id=i,conclusion=lits(i),flags=cat[i][2],cause_mask=mask,
                         distinct_B_input_occurrences=len(pp),support_leaf_cause_counts=causes,
                         ancestry_nodes=len(seen),examples=samples))
    x.data.close();x.file.close()
save(ev/'proof-witnesses.json',out)
for c,t in out.items():
    for row in t:
        print(c,row['learned_id'],row['cause_mask'],row['distinct_B_input_occurrences'],dict(row['support_leaf_cause_counts']),
            [(a['source_occurrence'],a['path'][:4], [(v['first_reason'],v['terminal_reason']) for v in a['unmapped_literals'][:2]])for a in row['examples'] if a['cause']])
