import hashlib, json, gzip, shutil, sys
from pathlib import Path
from collections import Counter
from itertools import zip_longest
import tempfile
base=Path.home()/'dependency-reuse'; tree=base/'rebuild-d2/native'; d=base/'runs/d2';ev=d/'release-evidence'
sys.path.insert(0,str(tree/'dependency-reuse/scripts'))
from run_d1 import CASES
from run_stock import BASE,save
from diff_d1 import digest
from recheck_d2 import restore
def inhash(path):
    with gzip.open(path,'rb') as f:
        h=hashlib.sha256()
        for block in iter(lambda:f.read(1<<20),b''):h.update(block)
    return h.hexdigest()
def native(path,typed):
    stream=gzip.open(path,'rb') if path.suffix=='.gz' else path.open('rb')
    terms={}; bindings=Counter();other=hashlib.sha256(); ordered=Counter(); csum=hashlib.sha256()
    with stream:
        for line in stream:
            tag=line.partition(b'\t')[0]
            ordered[tag]+=1
            if tag==b'TERM':
                _,n,op,typ,data,*children=line.rstrip(b'\n').split(b'\t')
                key=(op,typ,data,*(terms[c] for c in children))
                terms[n]=typed.setdefault(key,len(typed)+1)
            elif tag in (b'H',b'VALUE_DEF'):
                _,s,n=line.rstrip(b'\n').split(b'\t')
                bindings[tag,s,terms[n]]+=1
            else:
                other.update(line)
                if tag==b'C':csum.update(line)
    return (Counter(terms.values()),bindings,other.hexdigest(),csum.hexdigest(),ordered)
replayed={};extra=[]
for c in CASES:
    pair=ev/'pairs'/c
    rows=json.loads((pair/'runs.json').read_text())
    receipts=[]
    for r in rows['proofs']:
        k=r['repeat'];p=d/'release-replay'/c/str(k)
        assert (d/f'recheck-{c}-{k}.log').read_text().strip()==f'{c} {k} verified'
        # Replay regenerates all counts, including the exact timer footer for this repetition.
        assert (p/'metrics.tsv').read_bytes()==(pair/f'on-{k}/proof-metrics.tsv').read_bytes()
        receipts.append(dict(repeat=k,reconstructed_archive_sha256=r['raw_sha256'],
            metrics_sha256=digest(p/'metrics.tsv'),checked_table_sha256={n:digest(p/n) for n in ('learned.tsv','used.tsv','survivors.tsv')}))
    replayed[c]=receipts
    d1=BASE/'reports/evidence/d1';refpair=d1/'pairs'/c
    for row in json.loads((ev/'combined/summary.json').read_text()):
        if row['case']!=c:continue
        mode=row['mode'];src=d/'release-combined'/c/mode
        if row.get('raw_sha256'):
            with tempfile.TemporaryDirectory() as tmp:restore(ev,c,row,Path(tmp)/'proof')
        typed={}
        old=native(d1/'runs/record'/c/'P0/native.tsv.gz',typed)
        current=native(src/'native.tsv',typed)
        assert old==current,(c,mode)
        delta=d/'combined-diff'/c/mode
        same={name:inhash(delta/name)==inhash(refpair/name) for name in ('variables.tsv.gz','occurrences.tsv.gz','clause-keys.tsv.gz','clause-counts.tsv.gz')}
        orig=json.loads((refpair/'summary.json').read_text())
        new=json.loads((delta/'summary.json').read_text())
        eq={k:orig[k]==new[k] for k in ('variables','clauses','theory','assumptions','targets')}
        assert all(eq.values()) and all(same.values())
        extra.append(dict(case=c,mode=mode,byte_identical_manifest=row['manifest_matches_D1'],
            native_manifest_sha256=row['manifest_sha256'],original_native_D1_sha256=row['D1_manifest_sha256'],
            complete_ordered_B_Q_input_sha256=old[3],same_ordered_rows_outside_TERM_H_VALUE_DEF=True,
            term_structures_and_bound_expressions_equal=True,scoped_d1_tables_equal=same,D1_delta_sections_equal=eq,
            joint_p0_proof_reconstructed_sha256=row.get('raw_sha256')))
save(ev/'combined/identity-audit.json',extra)
save(ev/'offline-checks.json',dict(checker_sha256=digest(d/'release-tools/check'),replayed=replayed,
    distinct_primary_archives=9,additional_combined_proofs=3,compared_every_native_birth_in_order=True,
    compared_all_native_resident_clauses_and_root_units=True,checked_signed_resolution=True,
    comparisons='Signed learning, used base rows, translated survivors and every metric matched for all primary repetitions. The combined proofs reconstruct from the same graph payload.',
    public_invalidation_only=dict(binary_sha256=digest(d/'invalidation-audit'),source_sha256=digest(d/'invalidation-audit.cpp'),
        compilation='g++ -std=c++11 -O2 -Isrc -I minisat-2.2.1 invalidation-audit.cpp minisat-2.2.1/minisat/core/ProofStore.cc',
        inputs='on-1 raw proof and prepare_d2.py inputs.txt',cpu=0,all_retained_ids_equal=True)))
