// Exercise only the public retirement API. Bind every D1 row to its exact
// original P0 occurrence once before the timed reverse traversal.
#include "minisat/core/ProofStore.h"
#include <chrono>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>

int main(int argc, char **argv)
{
    using namespace Minisat;
    using Clock = std::chrono::steady_clock;
    if(argc != 3) return 2;
    try
    {
        const auto start = Clock::now();
        ProofStore g;
        const int status = g.read(argv[1]);
        if(status != 0 && status != 10) throw std::runtime_error("incomplete run");
        const auto loaded = Clock::now();
        std::ifstream input(argv[2]);
        std::vector<uint8_t> matched;
        matched.reserve(g.inputs.size());
        std::string line;
        for(const auto &record : g.inputs)
        {
            if(!std::getline(input,line)) throw std::runtime_error("missing input row");
            std::istringstream row(line);
            char scope;
            unsigned cause;
            if(!(row >> scope >> cause) || cause > 255 || (cause & 56))
                throw std::runtime_error("malformed D1 delta");
            const auto kind = g.nodes.at(record.leaf).kind;
            if((kind==BooleanInput && scope!='B') || (kind==QueryInput && scope!='Q') ||
               (kind==UnknownInput && scope!='U') || (kind!=BooleanInput && kind!=QueryInput && kind!=UnknownInput))
                throw std::runtime_error("scope mismatch");
            int literal;
            for(auto p=g.litBegin(record.leaf); p<g.nodes.at(record.leaf).lit_end; ++p)
                if(!(row >> literal) || literal!=g.lits.at(p))
                    throw std::runtime_error("input content mismatch");
            row >> std::ws;
            if(!row.eof()) throw std::runtime_error("extra literals");
            matched.push_back(cause==0);
        }
        if(std::getline(input,line) || !input.eof()) throw std::runtime_error("unexpected input tail");
        const auto bound = Clock::now();
        const auto dead = g.invalidatedInputs(matched);
        const auto invalidated = Clock::now();
        for(const auto &birth : g.learned)
            if(!dead.at(birth.id)) std::cout << birth.id << '\n';
        const auto ns = [](Clock::duration elapsed) {return std::chrono::duration_cast<std::chrono::nanoseconds>(elapsed).count();};
        std::cerr << "archive_read_ns " << ns(loaded-start) << "\ninput_bind_ns " << ns(bound-loaded)
                  << "\nreverse_invalidation_ns " << ns(invalidated-bound) << '\n';
        return std::cout && std::cerr ? 0 : 2;
    }
    catch(const std::exception &e) { std::cerr << e.what() << '\n'; return 1; }
}
