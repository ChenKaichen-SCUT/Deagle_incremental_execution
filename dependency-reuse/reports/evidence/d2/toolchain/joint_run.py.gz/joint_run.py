"""Supplement the record-on/off matrix with frozen D1 identity recording costs."""
import gzip, json, shutil, sys
from pathlib import Path
source, binary, dest, evidence = [Path(p).resolve() for p in sys.argv[1:]]
sys.path.insert(0,str(source/'dependency-reuse/scripts'))
from run_stock import BASE,run,save
from run_d1 import CASES
from package_d1 import packed, metrics, trace_comparison
from diff_d1 import digest
from recheck_d2 import logical_sha
from summarize_stock import interpret
dest.mkdir(parents=True,exist_ok=False)
ev=evidence/'combined'
ev.mkdir()
specs=json.loads((BASE/'bench/manifest.json').read_text())
schedule=[(case,mode) for i,case in enumerate(CASES) for mode in
          (('identity','identity-and-proof') if i%2==0 else ('identity-and-proof','identity'))]
save(dest/'plan.json',dict(schedule=schedule,repeats=1,cpu=0,serial=True,binary_sha256=digest(binary),
    purpose='Separate descriptive cost of acquiring D1 identity records and D2 dependencies in the same P0 process. All six runs reported.'))
shutil.copyfile(dest/'plan.json',ev/'plan.json')
baseline=BASE/'reports/evidence/d1'
records=[]
for case,mode in schedule:
    out=dest/case/mode
    spec=dict(specs[case])
    flags=['--d1-manifest',str(out/'native.tsv')]
    if mode=='identity-and-proof': flags+=['--d2-proof',str(out/'proof.bin')]
    spec['argv']=flags+spec['argv']
    run(binary,spec,case,'P0',out,digest(binary))
    meta=json.loads((out/'run.json').read_text())
    properties,trace=interpret(meta,(out/'stdout').read_text())
    with gzip.open(baseline/'runs/off'/case/'P0/result.json.gz','rt') as f:ref,witness=json.load(f)
    assert metrics(properties)==metrics(ref) and meta['exit_code']==10 and not meta['timed_out']
    native=digest(out/'native.tsv')
    expect=json.loads((baseline/'pairs'/case/'summary.json').read_text())['native_sha256'][0]
    logical=logical_sha(out/'proof.bin')[0] if mode=='identity-and-proof' else None
    prior=json.loads((evidence/'pairs'/case/'runs.json').read_text())['proofs'][0]
    matches=logical==prior['logical_sha256'] if logical else None
    row=dict(case=case,mode=mode,wall_s=meta['wall_ns']/1e9,rss_kib=meta['peak_rss_kib'],
             solver_s=properties['queries'][0]['property_decider_solve_s'],trace=trace_comparison(witness,trace),
             manifest_sha256=native,D1_manifest_sha256=expect,manifest_matches_D1=(native==expect),
             manifest_bytes=(out/'native.tsv').stat().st_size,proof_logical_sha256=logical,
             proof_matches_primary=matches)
    target=ev/case/mode;target.mkdir(parents=True)
    for name in ('stdout','stderr'):packed(out/name,target/(name+'.gz'))
    shutil.copyfile(out/'run.json',target/'run.json')
    save(target/'result.json',properties)
    if logical is not None:
        _,clocks=logical_sha(out/'proof.bin')
        row.update(raw_sha256=digest(out/'proof.bin'),footer_clocks=clocks,compressed_payload=prior['compressed_payload'])
        if not matches:packed(out/'proof.bin',target/'proof.bin.gz')
    if native!=expect:packed(out/'native.tsv',target/'native.tsv.gz')
    records.append(row)
save(ev/'summary.json',records)
