import json,sys
from pathlib import Path
from difflib import SequenceMatcher
base=Path.home()/'dependency-reuse'
sys.path.insert(0,str(base/'native/dependency-reuse/scripts'))
from inspect_d2_used import Sites
from run_stock import BASE,save
d=base/'runs/d2'; ev=d/'release-evidence'; result={}
for case,symbol in [('circular-buffer','next#23'),('airline_reservations_6','bookings#9')]:
    paths=BASE/'reports/evidence/d1/runs/record'/case
    spec=json.loads((BASE/'bench/manifest.json').read_text())[case]['inputs']
    old,new=[Sites(paths/s/'native.tsv.gz') for s in ('P0','P1')]
    rows=[]
    for site,role,obj,typ in old.defs[symbol]:
        key,status,fn,file,ln=site
        peers=sorted(new.symbols.get((key,role,obj,typ),[]))
        row=dict(old_site=site,old_definition_role=role,old_object_key=obj,old_type_key=typ,
                 peer_symbols_at_same_site_role_object_type=peers)
        if file in spec['P0']:
            a,b=[(BASE/'bench'/case/spec[s][file]).read_text().splitlines() for s in ('P0','P1')]
            for i,j,n in SequenceMatcher(None,a,b,autojunk=False).get_matching_blocks():
                if i+1<=ln<=i+n:
                    row.update(same_source=dict(P0_line=ln,P1_line=ln+j-i,text=a[ln-1]))
                    break
        rows.append(row)
    result[case]=dict(P0_symbol=symbol,definitions=rows,
        native_P0_bit0=[k for k,v in old.bits.items() if any(s==symbol and bit==0 for s,t,bit in v)],
        same_spelling_P1_diagnostic_bit0=[k for k,v in new.bits.items() if any(s==symbol and bit==0 for s,t,bit in v)])
save(ev/'source-witnesses.json',result)
for c,r in result.items(): print(c,[(i['old_site'][2:],i.get('same_source'),len(i['peer_symbols_at_same_site_role_object_type'])) for i in r['definitions']])
