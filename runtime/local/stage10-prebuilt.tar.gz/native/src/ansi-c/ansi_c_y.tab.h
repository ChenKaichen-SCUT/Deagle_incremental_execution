/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YYANSI_C_ANSI_C_Y_TAB_H_INCLUDED
# define YY_YYANSI_C_ANSI_C_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yyansi_cdebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    TOK_AUTO = 258,                /* "auto"  */
    TOK_BOOL = 259,                /* "bool"  */
    TOK_COMPLEX = 260,             /* "complex"  */
    TOK_BREAK = 261,               /* "break"  */
    TOK_CASE = 262,                /* "case"  */
    TOK_CHAR = 263,                /* "char"  */
    TOK_CONST = 264,               /* "const"  */
    TOK_CONTINUE = 265,            /* "continue"  */
    TOK_DEFAULT = 266,             /* "default"  */
    TOK_DO = 267,                  /* "do"  */
    TOK_DOUBLE = 268,              /* "double"  */
    TOK_ELSE = 269,                /* "else"  */
    TOK_ENUM = 270,                /* "enum"  */
    TOK_EXTERN = 271,              /* "extern"  */
    TOK_FLOAT = 272,               /* "float"  */
    TOK_FOR = 273,                 /* "for"  */
    TOK_GOTO = 274,                /* "goto"  */
    TOK_IF = 275,                  /* "if"  */
    TOK_INLINE = 276,              /* "inline"  */
    TOK_INT = 277,                 /* "int"  */
    TOK_LONG = 278,                /* "long"  */
    TOK_REGISTER = 279,            /* "register"  */
    TOK_RESTRICT = 280,            /* "restrict"  */
    TOK_RETURN = 281,              /* "return"  */
    TOK_SHORT = 282,               /* "short"  */
    TOK_SIGNED = 283,              /* "signed"  */
    TOK_SIZEOF = 284,              /* "sizeof"  */
    TOK_STATIC = 285,              /* "static"  */
    TOK_STRUCT = 286,              /* "struct"  */
    TOK_SWITCH = 287,              /* "switch"  */
    TOK_TYPEDEF = 288,             /* "typedef"  */
    TOK_UNION = 289,               /* "union"  */
    TOK_UNSIGNED = 290,            /* "unsigned"  */
    TOK_VOID = 291,                /* "void"  */
    TOK_VOLATILE = 292,            /* "volatile"  */
    TOK_WCHAR_T = 293,             /* "wchar_t"  */
    TOK_WHILE = 294,               /* "while"  */
    TOK_ARROW = 295,               /* "->"  */
    TOK_INCR = 296,                /* "++"  */
    TOK_DECR = 297,                /* "--"  */
    TOK_SHIFTLEFT = 298,           /* "<<"  */
    TOK_SHIFTRIGHT = 299,          /* ">>"  */
    TOK_LE = 300,                  /* "<="  */
    TOK_GE = 301,                  /* ">="  */
    TOK_EQ = 302,                  /* "=="  */
    TOK_NE = 303,                  /* "!="  */
    TOK_ANDAND = 304,              /* "&&"  */
    TOK_OROR = 305,                /* "||"  */
    TOK_ELLIPSIS = 306,            /* "..."  */
    TOK_MULTASSIGN = 307,          /* "*="  */
    TOK_DIVASSIGN = 308,           /* "/="  */
    TOK_MODASSIGN = 309,           /* "%="  */
    TOK_PLUSASSIGN = 310,          /* "+="  */
    TOK_MINUSASSIGN = 311,         /* "-="  */
    TOK_SHLASSIGN = 312,           /* "<<="  */
    TOK_SHRASSIGN = 313,           /* ">>="  */
    TOK_ANDASSIGN = 314,           /* "&="  */
    TOK_XORASSIGN = 315,           /* "^="  */
    TOK_ORASSIGN = 316,            /* "|="  */
    TOK_IDENTIFIER = 317,          /* TOK_IDENTIFIER  */
    TOK_TYPEDEFNAME = 318,         /* TOK_TYPEDEFNAME  */
    TOK_INTEGER = 319,             /* TOK_INTEGER  */
    TOK_FLOATING = 320,            /* TOK_FLOATING  */
    TOK_CHARACTER = 321,           /* TOK_CHARACTER  */
    TOK_STRING = 322,              /* TOK_STRING  */
    TOK_ASM_STRING = 323,          /* TOK_ASM_STRING  */
    TOK_INT8 = 324,                /* "__int8"  */
    TOK_INT16 = 325,               /* "__int16"  */
    TOK_INT32 = 326,               /* "__int32"  */
    TOK_INT64 = 327,               /* "__int64"  */
    TOK_PTR32 = 328,               /* "__ptr32"  */
    TOK_PTR64 = 329,               /* "__ptr64"  */
    TOK_TYPEOF = 330,              /* "typeof"  */
    TOK_GCC_AUTO_TYPE = 331,       /* "__auto_type"  */
    TOK_GCC_FLOAT16 = 332,         /* "_Float16"  */
    TOK_GCC_FLOAT32 = 333,         /* "_Float32"  */
    TOK_GCC_FLOAT32X = 334,        /* "_Float32x"  */
    TOK_GCC_FLOAT80 = 335,         /* "__float80"  */
    TOK_GCC_FLOAT64 = 336,         /* "_Float64"  */
    TOK_GCC_FLOAT64X = 337,        /* "_Float64x"  */
    TOK_GCC_FLOAT128 = 338,        /* "_Float128"  */
    TOK_GCC_FLOAT128X = 339,       /* "_Float128x"  */
    TOK_GCC_INT128 = 340,          /* "__int128"  */
    TOK_GCC_DECIMAL32 = 341,       /* "_Decimal32"  */
    TOK_GCC_DECIMAL64 = 342,       /* "_Decimal64"  */
    TOK_GCC_DECIMAL128 = 343,      /* "_Decimal128"  */
    TOK_GCC_ASM = 344,             /* "__asm__"  */
    TOK_GCC_ASM_PAREN = 345,       /* "__asm__ (with parentheses)"  */
    TOK_GCC_ATTRIBUTE = 346,       /* "__attribute__"  */
    TOK_GCC_ATTRIBUTE_ALIGNED = 347, /* "aligned"  */
    TOK_GCC_ATTRIBUTE_TRANSPARENT_UNION = 348, /* "transparent_union"  */
    TOK_GCC_ATTRIBUTE_PACKED = 349, /* "packed"  */
    TOK_GCC_ATTRIBUTE_VECTOR_SIZE = 350, /* "vector_size"  */
    TOK_GCC_ATTRIBUTE_MODE = 351,  /* "mode"  */
    TOK_GCC_ATTRIBUTE_GNU_INLINE = 352, /* "__gnu_inline__"  */
    TOK_GCC_ATTRIBUTE_WEAK = 353,  /* "weak"  */
    TOK_GCC_ATTRIBUTE_ALIAS = 354, /* "alias"  */
    TOK_GCC_ATTRIBUTE_SECTION = 355, /* "section"  */
    TOK_GCC_ATTRIBUTE_NORETURN = 356, /* "noreturn"  */
    TOK_GCC_ATTRIBUTE_CONSTRUCTOR = 357, /* "constructor"  */
    TOK_GCC_ATTRIBUTE_DESTRUCTOR = 358, /* "destructor"  */
    TOK_GCC_ATTRIBUTE_FALLTHROUGH = 359, /* "fallthrough"  */
    TOK_GCC_ATTRIBUTE_USED = 360,  /* "used"  */
    TOK_GCC_LABEL = 361,           /* "__label__"  */
    TOK_MSC_ASM = 362,             /* "__asm"  */
    TOK_MSC_BASED = 363,           /* "__based"  */
    TOK_CW_VAR_ARG_TYPEOF = 364,   /* "_var_arg_typeof"  */
    TOK_BUILTIN_VA_ARG = 365,      /* "__builtin_va_arg"  */
    TOK_GCC_BUILTIN_TYPES_COMPATIBLE_P = 366, /* "__builtin_types_compatible_p"  */
    TOK_CLANG_BUILTIN_CONVERTVECTOR = 367, /* "__builtin_convertvector"  */
    TOK_OFFSETOF = 368,            /* "__offsetof"  */
    TOK_ALIGNOF = 369,             /* "__alignof__"  */
    TOK_MSC_TRY = 370,             /* "__try"  */
    TOK_MSC_FINALLY = 371,         /* "__finally"  */
    TOK_MSC_EXCEPT = 372,          /* "__except"  */
    TOK_MSC_LEAVE = 373,           /* "__leave"  */
    TOK_MSC_DECLSPEC = 374,        /* "__declspec"  */
    TOK_MSC_FORCEINLINE = 375,     /* "__forceinline"  */
    TOK_INTERFACE = 376,           /* "__interface"  */
    TOK_CDECL = 377,               /* "__cdecl"  */
    TOK_STDCALL = 378,             /* "__stdcall"  */
    TOK_FASTCALL = 379,            /* "__fastcall"  */
    TOK_CLRCALL = 380,             /* "__clrcall"  */
    TOK_FORALL = 381,              /* "forall"  */
    TOK_EXISTS = 382,              /* "exists"  */
    TOK_ACSL_FORALL = 383,         /* "\\forall"  */
    TOK_ACSL_EXISTS = 384,         /* "\\exists"  */
    TOK_ACSL_LAMBDA = 385,         /* "\\lambda"  */
    TOK_ACSL_LET = 386,            /* "\\let"  */
    TOK_ARRAY_OF = 387,            /* "array_of"  */
    TOK_CPROVER_BITVECTOR = 388,   /* "__CPROVER_bitvector"  */
    TOK_CPROVER_FLOATBV = 389,     /* "__CPROVER_floatbv"  */
    TOK_CPROVER_FIXEDBV = 390,     /* "__CPROVER_fixedbv"  */
    TOK_CPROVER_ATOMIC = 391,      /* "__CPROVER_atomic"  */
    TOK_CPROVER_BOOL = 392,        /* "__CPROVER_bool"  */
    TOK_CPROVER_THROW = 393,       /* "__CPROVER_throw"  */
    TOK_CPROVER_CATCH = 394,       /* "__CPROVER_catch"  */
    TOK_CPROVER_TRY = 395,         /* "__CPROVER_try"  */
    TOK_CPROVER_FINALLY = 396,     /* "__CPROVER_finally"  */
    TOK_CPROVER_ID = 397,          /* "__CPROVER_ID"  */
    TOK_CPROVER_LOOP_INVARIANT = 398, /* "__CPROVER_loop_invariant"  */
    TOK_CPROVER_DECREASES = 399,   /* "__CPROVER_decreases"  */
    TOK_CPROVER_REQUIRES_CONTRACT = 400, /* "__CPROVER_requires_contract"  */
    TOK_CPROVER_REQUIRES = 401,    /* "__CPROVER_requires"  */
    TOK_CPROVER_ENSURES_CONTRACT = 402, /* "__CPROVER_ensures_contract"  */
    TOK_CPROVER_ENSURES = 403,     /* "__CPROVER_ensures"  */
    TOK_CPROVER_ASSIGNS = 404,     /* "__CPROVER_assigns"  */
    TOK_CPROVER_FREES = 405,       /* "__CPROVER_frees"  */
    TOK_IMPLIES = 406,             /* "==>"  */
    TOK_EQUIVALENT = 407,          /* "<==>"  */
    TOK_XORXOR = 408,              /* "^^"  */
    TOK_TRUE = 409,                /* "TRUE"  */
    TOK_FALSE = 410,               /* "FALSE"  */
    TOK_REAL = 411,                /* "__real__"  */
    TOK_IMAG = 412,                /* "__imag__"  */
    TOK_ALIGNAS = 413,             /* "_Alignas"  */
    TOK_ATOMIC_TYPE_QUALIFIER = 414, /* "_Atomic"  */
    TOK_ATOMIC_TYPE_SPECIFIER = 415, /* "_Atomic()"  */
    TOK_GENERIC = 416,             /* "_Generic"  */
    TOK_IMAGINARY = 417,           /* "_Imaginary"  */
    TOK_NORETURN = 418,            /* "_Noreturn"  */
    TOK_STATIC_ASSERT = 419,       /* "_Static_assert"  */
    TOK_THREAD_LOCAL = 420,        /* "_Thread_local"  */
    TOK_NULLPTR = 421,             /* "nullptr"  */
    TOK_CONSTEXPR = 422,           /* "constexpr"  */
    TOK_SCANNER_ERROR = 423,       /* TOK_SCANNER_ERROR  */
    TOK_SCANNER_EOF = 424,         /* TOK_SCANNER_EOF  */
    TOK_CATCH = 425,               /* "catch"  */
    TOK_CHAR16_T = 426,            /* "char16_t"  */
    TOK_CHAR32_T = 427,            /* "char32_t"  */
    TOK_CLASS = 428,               /* "class"  */
    TOK_DELETE = 429,              /* "delete"  */
    TOK_DECLTYPE = 430,            /* "decltype"  */
    TOK_EXPLICIT = 431,            /* "explicit"  */
    TOK_FRIEND = 432,              /* "friend"  */
    TOK_MUTABLE = 433,             /* "mutable"  */
    TOK_NAMESPACE = 434,           /* "namespace"  */
    TOK_NEW = 435,                 /* "new"  */
    TOK_NOEXCEPT = 436,            /* "noexcept"  */
    TOK_OPERATOR = 437,            /* "operator"  */
    TOK_PRIVATE = 438,             /* "private"  */
    TOK_PROTECTED = 439,           /* "protected"  */
    TOK_PUBLIC = 440,              /* "public"  */
    TOK_TEMPLATE = 441,            /* "template"  */
    TOK_THIS = 442,                /* "this"  */
    TOK_THROW = 443,               /* "throw"  */
    TOK_TYPEID = 444,              /* "typeid"  */
    TOK_TYPENAME = 445,            /* "typename"  */
    TOK_TRY = 446,                 /* "try"  */
    TOK_USING = 447,               /* "using"  */
    TOK_VIRTUAL = 448,             /* "virtual"  */
    TOK_SCOPE = 449,               /* "::"  */
    TOK_DOTPM = 450,               /* ".*"  */
    TOK_ARROWPM = 451,             /* "->*"  */
    TOK_UNARY_TYPE_PREDICATE = 452, /* TOK_UNARY_TYPE_PREDICATE  */
    TOK_BINARY_TYPE_PREDICATE = 453, /* TOK_BINARY_TYPE_PREDICATE  */
    TOK_MSC_UUIDOF = 454,          /* "__uuidof"  */
    TOK_MSC_IF_EXISTS = 455,       /* "__if_exists"  */
    TOK_MSC_IF_NOT_EXISTS = 456,   /* "__if_not_exists"  */
    TOK_UNDERLYING_TYPE = 457      /* "__underlying_type"  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef int YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yyansi_clval;


int yyansi_cparse (void);


#endif /* !YY_YYANSI_C_ANSI_C_Y_TAB_H_INCLUDED  */
