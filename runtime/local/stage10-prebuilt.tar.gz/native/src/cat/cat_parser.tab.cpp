// A Bison parser, made by GNU Bison 3.8.2.

// Skeleton implementation for Bison LALR(1) parsers in C++

// Copyright (C) 2002-2015, 2018-2021 Free Software Foundation, Inc.

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.

// As a special exception, you may create a larger work that contains
// part or all of the Bison parser skeleton and distribute that work
// under terms of your choice, so long as that work isn't itself a
// parser generator using the skeleton or a modified version thereof
// as a parser skeleton.  Alternatively, if you modify or redistribute
// the parser skeleton itself, you may (at your option) remove this
// special exception, which will cause the skeleton and the resulting
// Bison output files to be licensed under the GNU General Public
// License without this special exception.

// This special exception was added by the Free Software Foundation in
// version 2.2 of Bison.

// DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
// especially those whose name start with YY_ or yy_.  They are
// private implementation details that can be changed or removed.





#include "cat_parser.tab.h"


// Unqualified %code blocks.
#line 23 "cat_parser.ypp"

 /*
  * KATER -- Automating Weak Memory Model Metatheory
  *
  * This program is free software; you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation; either version 3 of the License, or
  * (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program; if not, you can access it online at
  * http://www.gnu.org/licenses/gpl-3.0.html.
  */

  #include "cat_parsing_driver.h"
  #include "cat_type.h"
  #include <iostream>
  #include <memory>
  #include <unordered_map>
  #include <vector>

#line 73 "cat_parser.tab.cpp"


#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> // FIXME: INFRINGES ON USER NAME SPACE.
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif


// Whether we are compiled with exception support.
#ifndef YY_EXCEPTIONS
# if defined __GNUC__ && !defined __EXCEPTIONS
#  define YY_EXCEPTIONS 0
# else
#  define YY_EXCEPTIONS 1
# endif
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K].location)
/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

# ifndef YYLLOC_DEFAULT
#  define YYLLOC_DEFAULT(Current, Rhs, N)                               \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).begin  = YYRHSLOC (Rhs, 1).begin;                   \
          (Current).end    = YYRHSLOC (Rhs, N).end;                     \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).begin = (Current).end = YYRHSLOC (Rhs, 0).end;      \
        }                                                               \
    while (false)
# endif


// Enable debugging if requested.
#if YYDEBUG

// A pseudo ostream that takes yydebug_ into account.
# define YYCDEBUG if (yydebug_) (*yycdebug_)

# define YY_SYMBOL_PRINT(Title, Symbol)         \
  do {                                          \
    if (yydebug_)                               \
    {                                           \
      *yycdebug_ << Title << ' ';               \
      yy_print_ (*yycdebug_, Symbol);           \
      *yycdebug_ << '\n';                       \
    }                                           \
  } while (false)

# define YY_REDUCE_PRINT(Rule)          \
  do {                                  \
    if (yydebug_)                       \
      yy_reduce_print_ (Rule);          \
  } while (false)

# define YY_STACK_PRINT()               \
  do {                                  \
    if (yydebug_)                       \
      yy_stack_print_ ();                \
  } while (false)

#else // !YYDEBUG

# define YYCDEBUG if (false) std::cerr
# define YY_SYMBOL_PRINT(Title, Symbol)  YY_USE (Symbol)
# define YY_REDUCE_PRINT(Rule)           static_cast<void> (0)
# define YY_STACK_PRINT()                static_cast<void> (0)

#endif // !YYDEBUG

#define yyerrok         (yyerrstatus_ = 0)
#define yyclearin       (yyla.clear ())

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYRECOVERING()  (!!yyerrstatus_)

namespace yy {
#line 165 "cat_parser.tab.cpp"

  /// Build a parser object.
  parser::parser (cat_parsing_drivert& drv_yyarg)
#if YYDEBUG
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
#else
    :
#endif
      drv (drv_yyarg)
  {}

  parser::~parser ()
  {}

  parser::syntax_error::~syntax_error () YY_NOEXCEPT YY_NOTHROW
  {}

  /*---------.
  | symbol.  |
  `---------*/



  // by_state.
  parser::by_state::by_state () YY_NOEXCEPT
    : state (empty_state)
  {}

  parser::by_state::by_state (const by_state& that) YY_NOEXCEPT
    : state (that.state)
  {}

  void
  parser::by_state::clear () YY_NOEXCEPT
  {
    state = empty_state;
  }

  void
  parser::by_state::move (by_state& that)
  {
    state = that.state;
    that.clear ();
  }

  parser::by_state::by_state (state_type s) YY_NOEXCEPT
    : state (s)
  {}

  parser::symbol_kind_type
  parser::by_state::kind () const YY_NOEXCEPT
  {
    if (state == empty_state)
      return symbol_kind::S_YYEMPTY;
    else
      return YY_CAST (symbol_kind_type, yystos_[+state]);
  }

  parser::stack_symbol_type::stack_symbol_type ()
  {}

  parser::stack_symbol_type::stack_symbol_type (YY_RVREF (stack_symbol_type) that)
    : super_type (YY_MOVE (that.state), YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_rel: // rel
        value.YY_MOVE_OR_COPY< cat_relationt > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_ID: // ID
      case symbol_kind::S_QPATH: // QPATH
      case symbol_kind::S_qualified_ID: // qualified_ID
        value.YY_MOVE_OR_COPY< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

#if 201103L <= YY_CPLUSPLUS
    // that is emptied.
    that.state = empty_state;
#endif
  }

  parser::stack_symbol_type::stack_symbol_type (state_type s, YY_MOVE_REF (symbol_type) that)
    : super_type (s, YY_MOVE (that.location))
  {
    switch (that.kind ())
    {
      case symbol_kind::S_rel: // rel
        value.move< cat_relationt > (YY_MOVE (that.value));
        break;

      case symbol_kind::S_ID: // ID
      case symbol_kind::S_QPATH: // QPATH
      case symbol_kind::S_qualified_ID: // qualified_ID
        value.move< std::string > (YY_MOVE (that.value));
        break;

      default:
        break;
    }

    // that is emptied.
    that.kind_ = symbol_kind::S_YYEMPTY;
  }

#if YY_CPLUSPLUS < 201103L
  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (const stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_rel: // rel
        value.copy< cat_relationt > (that.value);
        break;

      case symbol_kind::S_ID: // ID
      case symbol_kind::S_QPATH: // QPATH
      case symbol_kind::S_qualified_ID: // qualified_ID
        value.copy< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    return *this;
  }

  parser::stack_symbol_type&
  parser::stack_symbol_type::operator= (stack_symbol_type& that)
  {
    state = that.state;
    switch (that.kind ())
    {
      case symbol_kind::S_rel: // rel
        value.move< cat_relationt > (that.value);
        break;

      case symbol_kind::S_ID: // ID
      case symbol_kind::S_QPATH: // QPATH
      case symbol_kind::S_qualified_ID: // qualified_ID
        value.move< std::string > (that.value);
        break;

      default:
        break;
    }

    location = that.location;
    // that is emptied.
    that.state = empty_state;
    return *this;
  }
#endif

  template <typename Base>
  void
  parser::yy_destroy_ (const char* yymsg, basic_symbol<Base>& yysym) const
  {
    if (yymsg)
      YY_SYMBOL_PRINT (yymsg, yysym);
  }

#if YYDEBUG
  template <typename Base>
  void
  parser::yy_print_ (std::ostream& yyo, const basic_symbol<Base>& yysym) const
  {
    std::ostream& yyoutput = yyo;
    YY_USE (yyoutput);
    if (yysym.empty ())
      yyo << "empty symbol";
    else
      {
        symbol_kind_type yykind = yysym.kind ();
        yyo << (yykind < YYNTOKENS ? "token" : "nterm")
            << ' ' << yysym.name () << " ("
            << yysym.location << ": ";
        YY_USE (yykind);
        yyo << ')';
      }
  }
#endif

  void
  parser::yypush_ (const char* m, YY_MOVE_REF (stack_symbol_type) sym)
  {
    if (m)
      YY_SYMBOL_PRINT (m, sym);
    yystack_.push (YY_MOVE (sym));
  }

  void
  parser::yypush_ (const char* m, state_type s, YY_MOVE_REF (symbol_type) sym)
  {
#if 201103L <= YY_CPLUSPLUS
    yypush_ (m, stack_symbol_type (s, std::move (sym)));
#else
    stack_symbol_type ss (s, sym);
    yypush_ (m, ss);
#endif
  }

  void
  parser::yypop_ (int n) YY_NOEXCEPT
  {
    yystack_.pop (n);
  }

#if YYDEBUG
  std::ostream&
  parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  parser::debug_level_type
  parser::debug_level () const
  {
    return yydebug_;
  }

  void
  parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }
#endif // YYDEBUG

  parser::state_type
  parser::yy_lr_goto_state_ (state_type yystate, int yysym)
  {
    int yyr = yypgoto_[yysym - YYNTOKENS] + yystate;
    if (0 <= yyr && yyr <= yylast_ && yycheck_[yyr] == yystate)
      return yytable_[yyr];
    else
      return yydefgoto_[yysym - YYNTOKENS];
  }

  bool
  parser::yy_pact_value_is_default_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yypact_ninf_;
  }

  bool
  parser::yy_table_value_is_error_ (int yyvalue) YY_NOEXCEPT
  {
    return yyvalue == yytable_ninf_;
  }

  int
  parser::operator() ()
  {
    return parse ();
  }

  int
  parser::parse ()
  {
    int yyn;
    /// Length of the RHS of the rule being reduced.
    int yylen = 0;

    // Error handling.
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// The lookahead symbol.
    symbol_type yyla;

    /// The locations where the error started and ended.
    stack_symbol_type yyerror_range[3];

    /// The return value of parse ().
    int yyresult;

#if YY_EXCEPTIONS
    try
#endif // YY_EXCEPTIONS
      {
    YYCDEBUG << "Starting parse\n";


    /* Initialize the stack.  The initial state will be set in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystack_.clear ();
    yypush_ (YY_NULLPTR, 0, YY_MOVE (yyla));

  /*-----------------------------------------------.
  | yynewstate -- push a new symbol on the stack.  |
  `-----------------------------------------------*/
  yynewstate:
    YYCDEBUG << "Entering state " << int (yystack_[0].state) << '\n';
    YY_STACK_PRINT ();

    // Accept?
    if (yystack_[0].state == yyfinal_)
      YYACCEPT;

    goto yybackup;


  /*-----------.
  | yybackup.  |
  `-----------*/
  yybackup:
    // Try to take a decision without lookahead.
    yyn = yypact_[+yystack_[0].state];
    if (yy_pact_value_is_default_ (yyn))
      goto yydefault;

    // Read a lookahead token.
    if (yyla.empty ())
      {
        YYCDEBUG << "Reading a token\n";
#if YY_EXCEPTIONS
        try
#endif // YY_EXCEPTIONS
          {
            symbol_type yylookahead (yylex (drv));
            yyla.move (yylookahead);
          }
#if YY_EXCEPTIONS
        catch (const syntax_error& yyexc)
          {
            YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
            error (yyexc);
            goto yyerrlab1;
          }
#endif // YY_EXCEPTIONS
      }
    YY_SYMBOL_PRINT ("Next token is", yyla);

    if (yyla.kind () == symbol_kind::S_YYerror)
    {
      // The scanner already issued an error message, process directly
      // to error recovery.  But do not keep the error token as
      // lookahead, it is too special and may lead us to an endless
      // loop in error recovery. */
      yyla.kind_ = symbol_kind::S_YYUNDEF;
      goto yyerrlab1;
    }

    /* If the proper action on seeing token YYLA.TYPE is to reduce or
       to detect an error, take that action.  */
    yyn += yyla.kind ();
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yyla.kind ())
      {
        goto yydefault;
      }

    // Reduce or error.
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
        if (yy_table_value_is_error_ (yyn))
          goto yyerrlab;
        yyn = -yyn;
        goto yyreduce;
      }

    // Count tokens shifted since error; after three, turn off error status.
    if (yyerrstatus_)
      --yyerrstatus_;

    // Shift the lookahead token.
    yypush_ ("Shifting", state_type (yyn), YY_MOVE (yyla));
    goto yynewstate;


  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[+yystack_[0].state];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;


  /*-----------------------------.
  | yyreduce -- do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    {
      stack_symbol_type yylhs;
      yylhs.state = yy_lr_goto_state_ (yystack_[yylen].state, yyr1_[yyn]);
      /* Variants are always initialized to an empty instance of the
         correct type. The default '$$ = $1' action is NOT applied
         when using variants.  */
      switch (yyr1_[yyn])
    {
      case symbol_kind::S_rel: // rel
        yylhs.value.emplace< cat_relationt > ();
        break;

      case symbol_kind::S_ID: // ID
      case symbol_kind::S_QPATH: // QPATH
      case symbol_kind::S_qualified_ID: // qualified_ID
        yylhs.value.emplace< std::string > ();
        break;

      default:
        break;
    }


      // Default location.
      {
        stack_type::slice range (yystack_, yylen);
        YYLLOC_DEFAULT (yylhs.location, range, yylen);
        yyerror_range[1].location = yylhs.location;
      }

      // Perform the reduction.
      YY_REDUCE_PRINT (yyn);
#if YY_EXCEPTIONS
      try
#endif // YY_EXCEPTIONS
        {
          switch (yyn)
            {
  case 2: // main: %empty
#line 112 "cat_parser.ypp"
                                { }
#line 609 "cat_parser.tab.cpp"
    break;

  case 3: // main: main decl
#line 113 "cat_parser.ypp"
                                { }
#line 615 "cat_parser.tab.cpp"
    break;

  case 4: // decl: "include" QPATH
#line 116 "cat_parser.ypp"
                                           { }
#line 621 "cat_parser.tab.cpp"
    break;

  case 5: // decl: QPATH
#line 117 "cat_parser.ypp"
          {}
#line 627 "cat_parser.tab.cpp"
    break;

  case 6: // decl: "let" ID "=" rel
#line 118 "cat_parser.ypp"
                                           { drv.rename_relation(std::move(yystack_[0].value.as < cat_relationt > ()), yystack_[2].value.as < std::string > (), false); }
#line 633 "cat_parser.tab.cpp"
    break;

  case 7: // decl: "let" "rec" ID "=" rel
#line 119 "cat_parser.ypp"
                                                 { drv.rename_relation(std::move(yystack_[0].value.as < cat_relationt > ()), yystack_[2].value.as < std::string > (), true); }
#line 639 "cat_parser.tab.cpp"
    break;

  case 8: // decl: "let" ID "=" "0"
#line 120 "cat_parser.ypp"
                                     { drv.make_dummy_relation(std::move(yystack_[2].value.as < std::string > ())); }
#line 645 "cat_parser.tab.cpp"
    break;

  case 10: // qualified_ID: ID
#line 124 "cat_parser.ypp"
                        { yylhs.value.as < std::string > () = yystack_[0].value.as < std::string > (); }
#line 651 "cat_parser.tab.cpp"
    break;

  case 11: // qualified_ID: ID "::" ID
#line 125 "cat_parser.ypp"
                        { yylhs.value.as < std::string > () = yystack_[2].value.as < std::string > () + "::" + yystack_[0].value.as < std::string > (); }
#line 657 "cat_parser.tab.cpp"
    break;

  case 12: // constraint: "empty" rel
#line 128 "cat_parser.ypp"
                                        { drv.addConstraint(rel_axiomt::EMPTY, std::move(yystack_[0].value.as < cat_relationt > ())); }
#line 663 "cat_parser.tab.cpp"
    break;

  case 13: // constraint: "acyclic" rel
#line 129 "cat_parser.ypp"
                                { drv.addConstraint(rel_axiomt::ACYCLIC, std::move(yystack_[0].value.as < cat_relationt > ())); }
#line 669 "cat_parser.tab.cpp"
    break;

  case 14: // constraint: "irreflexive" rel
#line 130 "cat_parser.ypp"
                                { drv.addConstraint(rel_axiomt::IRREFLEXIVE, std::move(yystack_[0].value.as < cat_relationt > ())); }
#line 675 "cat_parser.tab.cpp"
    break;

  case 15: // constraint: "empty" rel "as" ID
#line 131 "cat_parser.ypp"
                        { drv.addConstraint(rel_axiomt::EMPTY, std::move(yystack_[2].value.as < cat_relationt > ())); }
#line 681 "cat_parser.tab.cpp"
    break;

  case 16: // constraint: "acyclic" rel "as" ID
#line 132 "cat_parser.ypp"
                                { drv.addConstraint(rel_axiomt::ACYCLIC, std::move(yystack_[2].value.as < cat_relationt > ())); }
#line 687 "cat_parser.tab.cpp"
    break;

  case 17: // constraint: "irreflexive" rel "as" ID
#line 133 "cat_parser.ypp"
                                        { drv.addConstraint(rel_axiomt::IRREFLEXIVE, std::move(yystack_[2].value.as < cat_relationt > ())); }
#line 693 "cat_parser.tab.cpp"
    break;

  case 18: // constraint: "flag" "~empty" rel
#line 134 "cat_parser.ypp"
                        { drv.addConstraint(rel_axiomt::NOT_EMPTY, std::move(yystack_[0].value.as < cat_relationt > ())); }
#line 699 "cat_parser.tab.cpp"
    break;

  case 19: // constraint: "flag" "~empty" rel "as" ID
#line 135 "cat_parser.ypp"
                                { drv.addConstraint(rel_axiomt::NOT_EMPTY, std::move(yystack_[2].value.as < cat_relationt > ())); }
#line 705 "cat_parser.tab.cpp"
    break;

  case 20: // rel: "id"
#line 138 "cat_parser.ypp"
                                    { yylhs.value.as < cat_relationt > () = drv.make_base("id"); }
#line 711 "cat_parser.tab.cpp"
    break;

  case 21: // rel: qualified_ID
#line 139 "cat_parser.ypp"
                                { yylhs.value.as < cat_relationt > () = cat_relationt(yystack_[0].value.as < std::string > (), rel_opt::TERMINAL, std::vector<std::string>{}); }
#line 717 "cat_parser.tab.cpp"
    break;

  case 22: // rel: "(" rel ")"
#line 140 "cat_parser.ypp"
                                  { yylhs.value.as < cat_relationt > () = std::move(yystack_[1].value.as < cat_relationt > ()); }
#line 723 "cat_parser.tab.cpp"
    break;

  case 23: // rel: "[" rel "]"
#line 141 "cat_parser.ypp"
                                  { yylhs.value.as < cat_relationt > () = drv.make_relation(rel_opt::BRACKET, std::vector<std::string>{yystack_[1].value.as < cat_relationt > ().name}); }
#line 729 "cat_parser.tab.cpp"
    break;

  case 24: // rel: "[" "]"
#line 142 "cat_parser.ypp"
                                      { yylhs.value.as < cat_relationt > () = drv.make_base("id"); }
#line 735 "cat_parser.tab.cpp"
    break;

  case 25: // rel: rel "|" rel
#line 143 "cat_parser.ypp"
                                  { yylhs.value.as < cat_relationt > () = drv.make_relation(rel_opt::ALT, std::vector<std::string>{yystack_[2].value.as < cat_relationt > ().name, yystack_[0].value.as < cat_relationt > ().name}); }
#line 741 "cat_parser.tab.cpp"
    break;

  case 26: // rel: rel ";" rel
#line 144 "cat_parser.ypp"
                                  { yylhs.value.as < cat_relationt > () = drv.make_relation(rel_opt::SEQ, std::vector<std::string>{yystack_[2].value.as < cat_relationt > ().name, yystack_[0].value.as < cat_relationt > ().name}); }
#line 747 "cat_parser.tab.cpp"
    break;

  case 27: // rel: rel "&" rel
#line 145 "cat_parser.ypp"
                                  { yylhs.value.as < cat_relationt > () = drv.make_relation(rel_opt::AND, std::vector<std::string>{yystack_[2].value.as < cat_relationt > ().name, yystack_[0].value.as < cat_relationt > ().name}); }
#line 753 "cat_parser.tab.cpp"
    break;

  case 28: // rel: rel "\\" rel
#line 146 "cat_parser.ypp"
                          { yylhs.value.as < cat_relationt > () = drv.make_relation(rel_opt::SUB, std::vector<std::string>{yystack_[2].value.as < cat_relationt > ().name, yystack_[0].value.as < cat_relationt > ().name}); }
#line 759 "cat_parser.tab.cpp"
    break;

  case 29: // rel: rel "*" rel
#line 147 "cat_parser.ypp"
                                  { yylhs.value.as < cat_relationt > () = drv.make_relation(rel_opt::PROD, std::vector<std::string>{yystack_[2].value.as < cat_relationt > ().name, yystack_[0].value.as < cat_relationt > ().name}); }
#line 765 "cat_parser.tab.cpp"
    break;

  case 30: // rel: rel "+"
#line 148 "cat_parser.ypp"
                                      { yylhs.value.as < cat_relationt > () = drv.make_relation(rel_opt::PLUS, std::vector<std::string>{yystack_[1].value.as < cat_relationt > ().name}); }
#line 771 "cat_parser.tab.cpp"
    break;

  case 31: // rel: rel "*"
#line 149 "cat_parser.ypp"
                    { yylhs.value.as < cat_relationt > () = drv.make_star(yystack_[1].value.as < cat_relationt > ().name); }
#line 777 "cat_parser.tab.cpp"
    break;

  case 32: // rel: rel "?"
#line 150 "cat_parser.ypp"
                                      { yylhs.value.as < cat_relationt > () = drv.make_qmark(yystack_[1].value.as < cat_relationt > ().name); }
#line 783 "cat_parser.tab.cpp"
    break;

  case 33: // rel: rel "^" "-1"
#line 151 "cat_parser.ypp"
                                { yylhs.value.as < cat_relationt > () = drv.make_relation(rel_opt::FLIP, std::vector<std::string>{yystack_[2].value.as < cat_relationt > ().name}); }
#line 789 "cat_parser.tab.cpp"
    break;

  case 34: // rel: "fencerel" rel
#line 152 "cat_parser.ypp"
                    { yylhs.value.as < cat_relationt > () = drv.make_fencerel(yystack_[0].value.as < cat_relationt > ().name); }
#line 795 "cat_parser.tab.cpp"
    break;


#line 799 "cat_parser.tab.cpp"

            default:
              break;
            }
        }
#if YY_EXCEPTIONS
      catch (const syntax_error& yyexc)
        {
          YYCDEBUG << "Caught exception: " << yyexc.what() << '\n';
          error (yyexc);
          YYERROR;
        }
#endif // YY_EXCEPTIONS
      YY_SYMBOL_PRINT ("-> $$ =", yylhs);
      yypop_ (yylen);
      yylen = 0;

      // Shift the result of the reduction.
      yypush_ (YY_NULLPTR, YY_MOVE (yylhs));
    }
    goto yynewstate;


  /*--------------------------------------.
  | yyerrlab -- here on detecting error.  |
  `--------------------------------------*/
  yyerrlab:
    // If not already recovering from an error, report this error.
    if (!yyerrstatus_)
      {
        ++yynerrs_;
        std::string msg = YY_("syntax error");
        error (yyla.location, YY_MOVE (msg));
      }


    yyerror_range[1].location = yyla.location;
    if (yyerrstatus_ == 3)
      {
        /* If just tried and failed to reuse lookahead token after an
           error, discard it.  */

        // Return failure if at end of input.
        if (yyla.kind () == symbol_kind::S_YYEOF)
          YYABORT;
        else if (!yyla.empty ())
          {
            yy_destroy_ ("Error: discarding", yyla);
            yyla.clear ();
          }
      }

    // Else will try to reuse lookahead token after shifting the error token.
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:
    /* Pacify compilers when the user code never invokes YYERROR and
       the label yyerrorlab therefore never appears in user code.  */
    if (false)
      YYERROR;

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    YY_STACK_PRINT ();
    goto yyerrlab1;


  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;   // Each real token shifted decrements this.
    // Pop stack until we find a state that shifts the error token.
    for (;;)
      {
        yyn = yypact_[+yystack_[0].state];
        if (!yy_pact_value_is_default_ (yyn))
          {
            yyn += symbol_kind::S_YYerror;
            if (0 <= yyn && yyn <= yylast_
                && yycheck_[yyn] == symbol_kind::S_YYerror)
              {
                yyn = yytable_[yyn];
                if (0 < yyn)
                  break;
              }
          }

        // Pop the current state because it cannot handle the error token.
        if (yystack_.size () == 1)
          YYABORT;

        yyerror_range[1].location = yystack_[0].location;
        yy_destroy_ ("Error: popping", yystack_[0]);
        yypop_ ();
        YY_STACK_PRINT ();
      }
    {
      stack_symbol_type error_token;

      yyerror_range[2].location = yyla.location;
      YYLLOC_DEFAULT (error_token.location, yyerror_range, 2);

      // Shift the error token.
      error_token.state = state_type (yyn);
      yypush_ ("Shifting", YY_MOVE (error_token));
    }
    goto yynewstate;


  /*-------------------------------------.
  | yyacceptlab -- YYACCEPT comes here.  |
  `-------------------------------------*/
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;


  /*-----------------------------------.
  | yyabortlab -- YYABORT comes here.  |
  `-----------------------------------*/
  yyabortlab:
    yyresult = 1;
    goto yyreturn;


  /*-----------------------------------------------------.
  | yyreturn -- parsing is finished, return the result.  |
  `-----------------------------------------------------*/
  yyreturn:
    if (!yyla.empty ())
      yy_destroy_ ("Cleanup: discarding lookahead", yyla);

    /* Do not reclaim the symbols of the rule whose action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    YY_STACK_PRINT ();
    while (1 < yystack_.size ())
      {
        yy_destroy_ ("Cleanup: popping", yystack_[0]);
        yypop_ ();
      }

    return yyresult;
  }
#if YY_EXCEPTIONS
    catch (...)
      {
        YYCDEBUG << "Exception caught: cleaning lookahead and stack\n";
        // Do not try to display the values of the reclaimed symbols,
        // as their printers might throw an exception.
        if (!yyla.empty ())
          yy_destroy_ (YY_NULLPTR, yyla);

        while (1 < yystack_.size ())
          {
            yy_destroy_ (YY_NULLPTR, yystack_[0]);
            yypop_ ();
          }
        throw;
      }
#endif // YY_EXCEPTIONS
  }

  void
  parser::error (const syntax_error& yyexc)
  {
    error (yyexc.location, yyexc.what ());
  }

#if YYDEBUG || 0
  const char *
  parser::symbol_name (symbol_kind_type yysymbol)
  {
    return yytname_[yysymbol];
  }
#endif // #if YYDEBUG || 0









  const signed char parser::yypact_ninf_ = -37;

  const signed char parser::yytable_ninf_ = -1;

  const short
  parser::yypact_[] =
  {
     -37,     8,   -37,    19,    19,    19,    -6,   -36,   -14,   -37,
     -37,   -37,   -37,    19,     2,    19,   -17,   -37,    33,    53,
      65,    19,   -37,   -33,    13,    97,   -37,   109,   -37,   -32,
       3,    19,    19,    19,    19,   -37,    19,   -37,    18,     5,
      10,    85,    34,    12,   -37,   -37,   -37,   -37,    37,   -11,
     130,   -11,    37,   -37,   -37,   -37,    17,    19,   -37,   121,
     -37,   121
  };

  const signed char
  parser::yydefact_[] =
  {
       2,     0,     1,     0,     0,     0,     0,     0,     0,     5,
       3,     9,    20,     0,     0,     0,    10,    21,    13,    14,
      12,     0,     4,     0,     0,     0,    24,     0,    34,     0,
       0,     0,     0,     0,     0,    30,    31,    32,     0,     0,
       0,    18,     0,     0,    22,    23,    11,    16,    26,    27,
      25,    28,    29,    33,    17,    15,     0,     0,     8,     6,
      19,     7
  };

  const signed char
  parser::yypgoto_[] =
  {
     -37,   -37,   -37,   -37,   -37,    -4
  };

  const signed char
  parser::yydefgoto_[] =
  {
       0,     1,    10,    17,    11,    18
  };

  const signed char
  parser::yytable_[] =
  {
      19,    20,    23,    21,    22,    29,    42,    46,     2,    25,
      27,    28,     3,     4,    12,    31,     5,    41,     6,    35,
      36,    37,     7,     8,    12,    24,    38,    48,    49,    50,
      51,    12,    52,     0,    43,    13,    58,    14,    26,    59,
      15,    16,    47,    53,    54,    13,    30,    14,     9,    55,
      15,    16,    13,    61,    14,    57,    60,    15,    16,    31,
      32,    33,    34,    35,    36,    37,    39,    35,    36,    37,
      38,     0,     0,     0,    38,     0,     0,     0,    40,    31,
      32,    33,    34,    35,    36,    37,     0,     0,     0,     0,
      38,    31,    32,    33,    34,    35,    36,    37,    56,     0,
       0,     0,    38,     0,     0,     0,     0,     0,     0,     0,
       0,    31,    32,    33,    34,    35,    36,    37,     0,     0,
       0,     0,    38,    31,    32,    33,    34,    35,    36,    37,
       0,    44,     0,     0,    38,    31,    32,    33,    34,    35,
      36,    37,     0,     0,     0,    45,    38,    31,    32,    33,
      34,    35,    36,    37,     0,     0,    31,    32,    38,    34,
      35,    36,    37,     0,     0,     0,     0,    38
  };

  const signed char
  parser::yycheck_[] =
  {
       4,     5,    16,     9,    40,    22,    39,    39,     0,    13,
      14,    15,     4,     5,    12,    26,     8,    21,    10,    30,
      31,    32,    14,    15,    12,    39,    37,    31,    32,    33,
      34,    12,    36,    -1,    21,    33,    24,    35,    36,    43,
      38,    39,    39,    25,    39,    33,    13,    35,    40,    39,
      38,    39,    33,    57,    35,    21,    39,    38,    39,    26,
      27,    28,    29,    30,    31,    32,    13,    30,    31,    32,
      37,    -1,    -1,    -1,    37,    -1,    -1,    -1,    13,    26,
      27,    28,    29,    30,    31,    32,    -1,    -1,    -1,    -1,
      37,    26,    27,    28,    29,    30,    31,    32,    13,    -1,
      -1,    -1,    37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    26,    27,    28,    29,    30,    31,    32,    -1,    -1,
      -1,    -1,    37,    26,    27,    28,    29,    30,    31,    32,
      -1,    34,    -1,    -1,    37,    26,    27,    28,    29,    30,
      31,    32,    -1,    -1,    -1,    36,    37,    26,    27,    28,
      29,    30,    31,    32,    -1,    -1,    26,    27,    37,    29,
      30,    31,    32,    -1,    -1,    -1,    -1,    37
  };

  const signed char
  parser::yystos_[] =
  {
       0,    42,     0,     4,     5,     8,    10,    14,    15,    40,
      43,    45,    12,    33,    35,    38,    39,    44,    46,    46,
      46,     9,    40,    16,    39,    46,    36,    46,    46,    22,
      13,    26,    27,    28,    29,    30,    31,    32,    37,    13,
      13,    46,    39,    21,    34,    36,    39,    39,    46,    46,
      46,    46,    46,    25,    39,    39,    13,    21,    24,    46,
      39,    46
  };

  const signed char
  parser::yyr1_[] =
  {
       0,    41,    42,    42,    43,    43,    43,    43,    43,    43,
      44,    44,    45,    45,    45,    45,    45,    45,    45,    45,
      46,    46,    46,    46,    46,    46,    46,    46,    46,    46,
      46,    46,    46,    46,    46
  };

  const signed char
  parser::yyr2_[] =
  {
       0,     2,     0,     2,     2,     1,     4,     5,     4,     1,
       1,     3,     2,     2,     2,     4,     4,     4,     3,     5,
       1,     1,     3,     3,     2,     3,     3,     3,     3,     3,
       2,     2,     2,     3,     2
  };


#if YYDEBUG
  // YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
  // First, the terminals, then, starting at \a YYNTOKENS, nonterminals.
  const char*
  const parser::yytname_[] =
  {
  "YYEOF", "error", "\"invalid token\"", "\"free\"", "\"acyclic\"",
  "\"irreflexive\"", "\"declare\"", "\"declare-loc\"", "\"empty\"",
  "\"~empty\"", "\"flag\"", "\"error\"", "\"id\"", "\"as\"", "\"include\"",
  "\"let\"", "\"rec\"", "\"save\"", "\"total\"", "\"view\"", "\"warning\"",
  "\"=\"", "\"::\"", "\",\"", "\"0\"", "\"-1\"", "\";\"", "\"&\"", "\"|\"",
  "\"\\\\\"", "\"+\"", "\"*\"", "\"?\"", "\"(\"", "\")\"", "\"[\"",
  "\"]\"", "\"^\"", "\"fencerel\"", "ID", "QPATH", "$accept", "main",
  "decl", "qualified_ID", "constraint", "rel", YY_NULLPTR
  };
#endif


#if YYDEBUG
  const unsigned char
  parser::yyrline_[] =
  {
       0,   112,   112,   113,   116,   117,   118,   119,   120,   121,
     124,   125,   128,   129,   130,   131,   132,   133,   134,   135,
     138,   139,   140,   141,   142,   143,   144,   145,   146,   147,
     148,   149,   150,   151,   152
  };

  void
  parser::yy_stack_print_ () const
  {
    *yycdebug_ << "Stack now";
    for (stack_type::const_iterator
           i = yystack_.begin (),
           i_end = yystack_.end ();
         i != i_end; ++i)
      *yycdebug_ << ' ' << int (i->state);
    *yycdebug_ << '\n';
  }

  void
  parser::yy_reduce_print_ (int yyrule) const
  {
    int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    // Print the symbols being reduced, and their result.
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
               << " (line " << yylno << "):\n";
    // The symbols being reduced.
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
                       yystack_[(yynrhs) - (yyi + 1)]);
  }
#endif // YYDEBUG


} // yy
#line 1164 "cat_parser.tab.cpp"

#line 155 "cat_parser.ypp"


void yy::parser::error(const location_type &l, const std::string &m)
{
	std::cerr << "\n" << l << ": " << m << "\n";
}

/* void yy::parser::report_syntax_error(const yy::parser::context &ctx) const
{
	std::cerr << ctx.location() << ": error";

	{
		enum { TOKENMAX = 5 };
		symbol_kind_type expected[TOKENMAX];

		auto n = ctx.expected_tokens(expected, TOKENMAX);
		for (auto i = 0; i < n; i++)
			std::cerr << (i == 0 ? ": expected \'" : "\' or \'") << symbol_name(expected[i]);
		if (n > 0)
			std::cerr << "\'";
	}

	{
		auto lookahead = ctx.token();
		if (lookahead != symbol_kind::S_YYEMPTY)
			std::cerr << " before \'" << symbol_name (lookahead) << "\'";
	}

	std::cerr << '\n';

	{
		auto &loc = ctx.location();
		std::cerr << current_line;
		for (auto i = 0; i < loc.begin.column-1; i++)
			std::cerr << " ";
		std::cerr << "^";
		for (auto i = loc.begin.column+1; i < loc.end.column; i++)
			std::cerr << "~";
		std::cerr << "\n";
		reset_current_line();
	}
} */
