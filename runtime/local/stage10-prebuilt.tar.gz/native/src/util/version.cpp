const char *CBMC_VERSION="5.67.0";
const char *DEAGLE_VERSION="4.2.0 (a2ba2f01-dirty)";
