"""Offline, byte-level release verification; use --seal once to write the publication manifest."""
from pathlib import Path
import argparse,collections,gzip,hashlib,json,tempfile
from raw_store import archive
from weak_controls import main as weak_check
from witness import result
ROOT=Path(__file__).resolve().parents[2]
E=ROOT/'reports/evidence/stage-11b'
def read(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def check():
    data=read(E/'trials.json');summary=read(E/'summary.json');idx=read(E/'raw/files.json')
    assert len(data)==105 and len(summary['cases'])==5
    assert set(summary['native_release'])=={'ACCEPT_NATIVE_RESTRICTED'} and summary['native_release']['ACCEPT_NATIVE_RESTRICTED']==200
    proofmeta=read(E/'proof-replay.json');blob=gzip.decompress((E/'proofs.json.gz').read_bytes())
    assert sha(blob)==proofmeta['proof_bytes_sha256'];proofs=json.loads(blob)
    for name,req in proofs.items():
        steps=req['proofs'];assert len(steps)==proofmeta['cases'][name]['consumed']
        assert len(steps)==summary['cases'][name]['modes']['GS']['median']['used_derived']
        old,new=[set(map(tuple,rows)) for rows in req['direct_PO_quotient']]
        for v in steps:
            a,b=v['pair'];assert (a,b) not in old
            for path,base in ((v['P0'],old),(v['P1'],new)):
                assert path[0]==a and path[-1]==b and all(x in base for x in zip(path,path[1:]))
    witnesses=read(E/'witnesses.json');checked=set()
    with archive(E/'raw') as z,tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp)
        for key in set(idx.values()):assert sha(z.read(key))==key
        weak_check(E/'panel',tmp/'weak.json')
        assert (tmp/'weak.json').read_bytes()==(E/'weak-sc.json').read_bytes()
        for p in data:
            if p['mode']=='stock':continue
            for side,r in zip(('old','new'),p['sides']):
                w=r.get('witness')
                if w is None or w in checked:continue
                prefix=f"formal/{p['case']}/{p['trial']}/{p['mode']}/{side}/"
                for n in ('full_model.json','native-bindings.json','bits.tsv','answer.txt'):
                    (tmp/n).write_bytes(z.read(idx[prefix+n]))
                observed=result(tmp);assert observed==witnesses[w] and observed['status']=='EXPLICIT_SC_ORDER'
                checked.add(w)
        assert checked==set(witnesses)
    for k,row in summary['cases'].items():
        assert all(t['repetitions']==5 for t in row['modes'].values())
    for ver in ('P0','P1'):
        ar=read(E/'multiquery'/ver/'receipt.json')
        assert ar['classification']=='INCOMPLETE_UNWINDING' and len(ar['stream']['queries'])==3
    assert read(E/'controls.json')['finite']['versions']==228
    assert read(ROOT/'project_state.json')['status']=='READY_FOR_REVIEW'
def manifest():
    roots=[E,ROOT/'scripts/stage11b']
    paths=[p for top in roots for p in top.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    paths.extend([ROOT/'reports/stage-11b.md',ROOT/'project_state.json'])
    return {p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in sorted(paths) if p!=E/'manifest.json'}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seal',action='store_true');a=p.parse_args()
    check();doc=dict(base='88ac77921fee14f84e721d85d91a4b7296fe4e23',sha256=manifest())
    if a.seal:(E/'manifest.json').write_bytes((json.dumps(doc,sort_keys=True,indent=2)+'\n').encode())
    assert read(E/'manifest.json')==doc
    print('Verified',len(doc['sha256']),'release files, all raw objects, eight distinct SAT assignments, both weak-SC controls and all retained-order proofs.')
