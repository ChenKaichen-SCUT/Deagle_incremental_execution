"""Publication gate for a version/candidate. A rejected answer never becomes a strict result."""
import json
from pathlib import Path
from witness import result
def decide(row,independent,witness,strict=False):
    mismatch=[k for k in ('source','argv','phases','stream','graph','exit') if row.get(k)!=independent.get(k)]
    props=lambda r:[(p[0],p[1]) for p in r.get('properties',[])]
    if props(row)!=props(independent):mismatch.append('properties')
    if mismatch:
        return dict(path='FULL_REBUILD',basis='independent stock current version',errors=mismatch,
                    native_exit=independent['exit'],strict='UNESTABLISHED')
    if row.get('closure',{}).get('reason')=='admitted' and row.get('root_check') is None:
        return dict(path='FULL_REBUILD',basis='root oracle missing',native_exit=independent['exit'],strict='UNESTABLISHED')
    cert=witness.get('status')
    if cert=='NO_ORDER_FOR_RETURNED_ASSIGNMENT' or (strict and cert!='EXPLICIT_SC_ORDER'):
        return dict(path='FULL_REBUILD',basis='strict completion unavailable',native_exit=independent['exit'],strict='UNESTABLISHED')
    return dict(path='ACCEPT_NATIVE_RESTRICTED',native_exit=row['exit'],
                strict='EXPLICIT_SC_COUNTEREXAMPLE' if cert=='EXPLICIT_SC_ORDER' else 'UNESTABLISHED')
def verify(d,stock):
    row=json.loads((d/'receipt.json').read_bytes());ref=json.loads((stock/'receipt.json').read_bytes())
    witness=result(d) if row['exit']==10 else {'status':'NO_SAT_MODEL'}
    answer=dict(native=decide(row,ref,witness),strict_request=decide(row,ref,witness,True))
    (d/'gate.json').write_text(json.dumps(answer,sort_keys=True,indent=2)+'\n')
    return answer
