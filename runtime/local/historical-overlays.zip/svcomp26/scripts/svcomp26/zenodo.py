"""Read selected members of a frozen, large official Zenodo ZIP via checked byte ranges."""
import io
import urllib.request
import zipfile
from pathlib import Path

class Archive(io.RawIOBase):
    def __init__(self,url):
        self.url=url
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.at=0
        _,self.size=self._range('0-0')
    def _range(self,spec):
        req=urllib.request.Request(self.url+'?part='+spec,headers={'Range':'bytes='+spec,'User-Agent':'SV-COMP-2026-repair-study','Accept-Encoding':'identity'})
        with self.opener.open(req,timeout=90) as res:
            if res.status!=206:raise ValueError('official archive did not honor byte range')
            bounds,size=res.headers['Content-Range'].removeprefix('bytes ').split('/')
            if bounds!=spec:raise ValueError((spec,bounds))
            data=res.read()
        lo,hi=map(int,bounds.split('-'))
        if len(data)!=hi-lo+1:raise ValueError('short range')
        return data,int(size)
    def seekable(self):return True
    def tell(self):return self.at
    def seek(self,offset,whence=0):
        self.at=(0,self.at,self.size)[whence]+offset
        return self.at
    def read(self,n=-1):
        end=self.size if n<0 else min(self.size,self.at+n)
        if end<=self.at:return b''
        data,size=self._range(f'{self.at}-{end-1}')
        if size!=self.size:raise ValueError('archive identity changed')
        self.at=end
        return data
